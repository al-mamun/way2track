<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SalesOrderDetailstem extends Model
{
    protected $table = 'w2t_sales_order_detail_temporary';
    public $timestamp = true;
}
