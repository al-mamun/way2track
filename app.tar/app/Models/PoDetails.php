<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PoDetails extends Model
{
    protected $table = 'w2t_po_details';
    public $timestamp = true;
}
